{{/*
Expand the name of the chart.
*/}}
{{- define "tams.name" -}}
{{- .Chart.Name }}
{{- end }}

{{/* `dig`, not .tags.x: helm --reuse-values pins the OLD chart's values, where
     image.tags does not exist, and a plain lookup would nil-pointer there. */}}
{{- define "tams.serverImage" -}}
{{ .Values.image.registry }}/{{ .Values.image.repository }}/tams-server:{{ dig "tags" "server" "" .Values.image | default .Values.image.tag }}
{{- end }}

{{- define "tams.authImage" -}}
{{ .Values.image.registry }}/{{ .Values.image.repository }}/tams-auth-server:{{ dig "tags" "auth" "" .Values.image | default .Values.image.tag }}
{{- end }}

{{- define "tams.uiImage" -}}
{{ .Values.image.registry }}/{{ .Values.image.repository }}/tams-ui:{{ dig "tags" "web" "" .Values.image | default .Values.image.tag }}
{{- end }}

{{/*
Ingest-gateway image. Defaults to the chart's registry/repository and tag, but
both the repository and tag can be overridden under `ingestGateway.image`.
*/}}
{{- define "tams.ingestGatewayImage" -}}
{{- $repo := .Values.ingestGateway.image.repository | default (printf "%s/%s/tams-ingest-gateway" .Values.image.registry .Values.image.repository) -}}
{{- $tag := .Values.ingestGateway.image.tag | default .Values.image.tag -}}
{{ $repo }}:{{ $tag }}
{{- end }}

{{- define "tams.ingestUiImage" -}}
{{- $repo := .Values.ingestUi.image.repository | default (printf "%s/%s/tams-ingest-ui" .Values.image.registry .Values.image.repository) -}}
{{- $tag := .Values.ingestUi.image.tag | default .Values.image.tag -}}
{{ $repo }}:{{ $tag }}
{{- end }}

{{/*
Docker Hub pull secret. Rendered only when imagePullSecret.token is set; the
deployments reference it via "tams.imagePullSecrets".
*/}}
{{- define "tams.dockerconfigjson" -}}
{{- $reg := .Values.imagePullSecret.server -}}
{{- $user := .Values.imagePullSecret.username -}}
{{- $token := .Values.imagePullSecret.token -}}
{{- $auth := printf "%s:%s" $user $token | b64enc -}}
{{- printf "{\"auths\":{\"%s\":{\"username\":\"%s\",\"password\":\"%s\",\"auth\":\"%s\"}}}" $reg $user $token $auth -}}
{{- end }}

{{- define "tams.imagePullSecrets" -}}
{{- if .Values.imagePullSecret.token -}}
imagePullSecrets:
  - name: tams-registry
{{- end -}}
{{- end }}

{{- define "tams.nodeAffinity" -}}
{{- if .Values.nodeAffinity.excludeHostname }}
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/hostname
              operator: NotIn
              values:
                - {{ .Values.nodeAffinity.excludeHostname }}
{{- end }}
{{- end }}

{{- define "tams.rendernodeImage" -}}
{{- $repo := .Values.rendernode.image.repository | default (printf "%s/%s/vecta-rendernode" .Values.image.registry .Values.image.repository) -}}
{{- $tag := .Values.rendernode.image.tag | default .Values.image.tag -}}
{{ $repo }}:{{ $tag }}
{{- end }}
